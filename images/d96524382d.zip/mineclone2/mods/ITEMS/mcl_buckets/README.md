# MineClone2 Bucket (`mcl_bucket`)
Originally taken from Minetest Game, adapted for MineClone2.

This mod add buckets to the game, including an API to register your own (see `API.md`).

## License

Copyright (C) 2011-2012 Kahrl <kahrl@gmx.net>

Copyright (C) 2011-2012 celeron55, Perttu Ahola <celeron55@gmail.com>

This program is free software; you can redistribute it and/or modify
it under the terms of the GNU Lesser General Public License as published by
the Free Software Foundation; either version 2 of the License, or
(at your option) any later version.

http://www.gnu.org/licenses/lgpl-2.1.html


