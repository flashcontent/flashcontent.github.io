# Blackstone Mod

This mod adds new Blocks: Blackstone, Basalt, Soul Fire, Soul Torch etc.

## Version:

Its version 1.0.2

## License

CC BY-SA 4.0
