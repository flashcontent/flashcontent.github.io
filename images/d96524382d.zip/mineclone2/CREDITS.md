# Credits

## Creator of MineClone
* davedevils

## Creator of MineClone2
* Wuzzy


## Maintainers
* AncientMariner
* Nicu

## Previous Maintainers
* Fleckenstein
* jordan4ibanez
* cora

## Developers
* bzoss
* AFCMS
* epCode
* ryvnf
* iliekprogrammar
* MysticTempest
* Rootyjr
* aligator
* Code-Sploit
* NO11
* kabou
* rudzik8
* chmodsayshello
* PrairieWind
* RandomLegoBrick
* SumianVoice
* MrRar
* talamh
* Faerraven / Michieal
* FossFanatic

## Contributors
* Laurent Rocher
* HimbeerserverDE
* TechDudie
* Alexander Minges
* ArTee3
* ZeDique la Ruleta
* pitchum
* wuniversales
* Bu-Gee
* David McMackins II
* Nicholas Niro
* Wouters Dorian
* Blue Blancmange
* Jared Moody
* Li0n
* Midgard
* Saku Laesvuori
* Yukitty
* ZedekThePD
* aldum
* dBeans
* nickolas360
* yutyo
* Tianyang Zhang
* j45
* Marcin Serwin
* erlehmann
* E
* Benjamin Schötz
* Doloment
* Sydney Gems
* Emily2255
* Emojigit
* FinishedFragment
* sfan5
* Blue Blancmange
* Jared Moody
* SmallJoker
* Sven792
* aldum
* Dieter44
* Pepebotella
* MrRar
* Lazerbeak12345
* mrminer
* Thunder1035
* opfromthestart
* snowyu
* FaceDeer
* Faerraven / Michieal
* FossFanatic
* Herbert West
* GuyLiner
* 3raven
* anarquimico
* TheOnlyJoeEnderman
* Ranko Saotome
* Gregor Parzefall
* Wbjitscool
* b3nderman

## MineClone5
* kay27
* Debiankaios
* epCode
* NO11
* j45
* chmodsayshello
* 3raven
* PrairieWind
* Gustavo6046 / wallabra
* CableGuy67
* MrRar

## Mineclonia
* erlehmann
* Li0n
* E
* n_to

## Original Mod Authors
* Wuzzy
* Fleckenstein
* BlockMen
* TenPlus1
* PilzAdam
* ryvnf
* stujones11
* Arcelmi
* celeron55
* maikerumine
* GunshipPenguin
* Qwertymine3
* Rochambeau
* rubenwardy
* stu
* 4aiman
* Kahrl
* Krock
* UgnilJoZ
* lordfingle
* 22i
* bzoss
* kilbith
* xeranas
* kddekadenz
* sofar
* 4Evergreen4
* jordan4ibanez
* paramat
* cora
* Faerraven / Michieal

## 3D Models
* 22i
* tobyplowy
* epCode
* Faerraven / Michieal

## Textures
* XSSheep
* Wuzzy
* kingoscargames
* leorockway
* xMrVizzy
* yutyo
* NO11
* kay27
* MysticTempest
* RandomLegoBrick
* cora
* Faerraven / Michieal
* Nicu

## Translations
* Wuzzy
* Rocher Laurent
* wuniversales
* kay27
* pitchum
* todoporlalibertad
* Marcin Serwin
* Pepebotella
* Emojigit
* snowyu
* 3raven
* SakuraRiu

## Funders
* 40W
* bauknecht
* Cora

## Special thanks
* celeron55 for creating Minetest
* Jordach for the jukebox music compilation from Big Freaking Dig
* wsor for working tirelessly in the shadows for the good of all of us, particularly helping with solving contentDB and copyright issues.
* The workaholics who spent way too much time writing for the Minecraft Wiki. It's an invaluable resource for creating this game
* Notch and Jeb for being the major forces behind Minecraft
* Dark Reaven Music (https://soundcloud.com/dark-reaven-music) for the main menu theme (Calmed Cube), which is licensed under https://creativecommons.org/licenses/by-sa/3.0/
