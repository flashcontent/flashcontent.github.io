License of code: WTFPL

License of textures: See README.md in top directory of MineClone 2.

License of models: GPLv3 (https://www.gnu.org/licenses/gpl-3.0.html)
Models author: 22i.
Source: https://github.com/22i/amc
