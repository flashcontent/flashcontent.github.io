# MineClone 2 HUD bar for `mcl_armor` [`mcl_hbarmor`]

## Description
This mod adds a simple HUD bar which displays the player's armor points.
The players has 0-20 armor points.

The armor bar is hidden if the player wears no armor.

## Licensing
This mod is entirly free softare.

### Source code
License: MIT License (see below)

### Textures

See MineClone 2 license.

### MIT License
Everything else is under the MIT License:
© Copyright BlockMen (2013-2014)

This program is free software. It comes without any warranty, to
the extent permitted by applicable law. You can redistribute it
and/or modify it under the terms of the MIT License.
See <https://opensource.org/licenses/MIT> for more details.
