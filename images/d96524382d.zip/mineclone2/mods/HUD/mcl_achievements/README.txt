License of this mod (including textures and other data): WTFPL
