Controls framework by Arcelmi.
https://github.com/Arcelmi/minetest-controls
