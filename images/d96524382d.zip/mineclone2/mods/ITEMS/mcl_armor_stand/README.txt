[mod] 3d Armor Stand [mcl_armor_stand]
======================================

Depends: mcl_armor

Adds an armor stand for armor storage and display.
