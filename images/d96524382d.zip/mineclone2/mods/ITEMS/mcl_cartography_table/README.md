mcl_cartography_table
-------------------
Cartography Tables, by PrairieWind

Adds Cartography Tables to MineClone 2/5.

License of source code
----------------------
LGPLv2.1

License of media
----------------
See the main MineClone 2 README.md file.