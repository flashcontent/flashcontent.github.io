# tga_encoder
A TGA Encoder written in Lua without the use of external Libraries.

May be used as a Minetest mod.
