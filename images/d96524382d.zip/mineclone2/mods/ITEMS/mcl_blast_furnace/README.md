Blast Furnaces for MineClone 2.
Heavily based on Minetest Game (default/furnace.lua) and the MineClone 2 Furnaces.

License of source code
----------------------
LGPLv2.1
Based on code from Minetest Game.
Modified by Wuzzy.
MCl 2 Furances modified by PrairieWind.

License of media
----------------
See the main MineClone 2 README.md file.
