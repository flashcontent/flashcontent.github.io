local modpath = minetest.get_modpath(minetest.get_current_modname())

dofile(modpath.."/snippets_base.lua")
dofile(modpath.."/snippets_mcl.lua")