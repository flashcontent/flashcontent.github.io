Credits of sound files:

Note: Most sounds have not been used verbatim, but tweaked a little to be more suitable for the noteblock mod.

### Sounds licensed CC0: 

	* by freesound.org user AmateurJ
	* Source: https://freesound.org/people/AmateurJ/sounds/399523/
* mesecons_noteblock_bass_drum.ogg
	* by freesound.org user Mattc90
	* Source: https://freesound.org/people/Mattc90/sounds/264285/
* mesecons_noteblock_bell.ogg
	* by opengameart.org user Brandon75689
	* Source: https://opengameart.org/content/point-bell
* mesecons_noteblock_chime.ogg
	* by freesound.org user
	* Source: https://freesound.org/people/ikonochris/sounds/213380/
* mesecons_noteblock_cowbell.ogg
	* by freesound.org user timgormly
	* Source: https://freesound.org/people/timgormly/sounds/159760/
* mesecons_noteblock_flute.ogg
	* by freesound.org user menegass
	* Source: https://freesound.org/people/menegass/sounds/107307/
* mesecons_noteblock_bass_guitar.ogg
	* by freesound.org user Vres
	* Source: https://freesound.org/people/Vres/sounds/133024/
* mesecons_noteblock_hit.ogg
	* by freesound.org user rubberduck
	* Source: https://opengameart.org/content/100-cc0-sfx
* mesecons_noteblock_piano_digital.ogg
	* by freesound.org user monotraum
	* Source: https://freesound.org/people/monotraum/sounds/208889/
* mesecons_noteblock_squarewave.ogg
	* by Wuzzy
* mesecons_noteblock_xylophone_metal.ogg
	* by freesound.org user JappeHallunken
	* Source: https://freesound.org/people/JappeHallunken/sounds/501300/
* mesecons_noteblock_xylophone_wood.ogg
	* by freesound.org user connersaw8
	* Source: https://freesound.org/people/connersaw8/sounds/125271/

### Sounds licensed CC BY 3.0:

* mesecons_noteblock_bass_guitar.ogg
	* by freesound.org user Kyster
	* Source: https://freesound.org/people/Kyster/sounds/117707/
* mesecons_noteblock_didgeridoo.ogg
	* by freesound.org user InspectorJ
	* Source: https://freesound.org/people/InspectorJ/sounds/398272/

Everything else:
Created by Mesecons authors, licensed CC BY 3.0.

--------------------
License links:
* CC0: http://creativecommons.org/publicdomain/zero/1.0/
* CC BY 3.0: http://creativecommons.org/licenses/by/3.0/
