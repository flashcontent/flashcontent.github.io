
if minetest.get_modpath("lucky_block") then

	lucky_block:add_blocks({
		{"dro", {"mcl_mobs:nametag"}, 1},
		{"lig"},
	})
end
