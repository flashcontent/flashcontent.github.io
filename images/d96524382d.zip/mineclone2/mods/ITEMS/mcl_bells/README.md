mcl_bells
---------
Village bells for MineClone2, originally imported from mcl5, heavily modified by cora.

License of media files
----------------------
* sounds/bell_stroke.ogg - cc0 http://creativecommons.org/publicdomain/zero/1.0/
	* created by edsward
	* modified by sorcerykid
	* obtained from https://freesound.org/people/edsward/sounds/341866/

* textures/mcl_bells_bell.png - cc4-by-sa https://creativecommons.org/licenses/by-sa/4.0/
	* from pixelperfection by XSSheep and NovaWostra ( https://www.planetminecraft.com/texture-pack/pixel-perfection-chorus-edit/ )
	
* textures/mcl_bells_bell_*.png - cc0 http://creativecommons.org/publicdomain/zero/1.0/
	* created by cora
